import React from 'react';

const CreateComment = () => {
    return (
        <div>
            <h1>Create Comment Page</h1>
        </div>
    );
};

export default CreateComment;
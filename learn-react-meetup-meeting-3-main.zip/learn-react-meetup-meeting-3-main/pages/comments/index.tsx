import React from 'react';

const Comments = () => {
    return (
        <div>
            <h1>Comments Page</h1>
        </div>
    );
};

export default Comments;
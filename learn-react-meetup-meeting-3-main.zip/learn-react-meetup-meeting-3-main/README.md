<h2>Motivation</h2>
Actual repo for <a href='https://www.meetup.com/learn-react-israel/events/286752210/'>meeting</a>